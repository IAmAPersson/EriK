﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;

public static class KnowledgeHandler
{
    public static Dictionary<string, Probil> Knowledge = new Dictionary<string, Probil>();
    private static string LastInput = "";

    public static void Save()
    {
        string SaveString = JsonConvert.SerializeObject(Knowledge);
        string Path = AppDomain.CurrentDomain.BaseDirectory + "\\Knowledge.json";
        var Temp = File.Create(Path);
        Temp.Close();
        File.WriteAllText(Path, SaveString);
    }

    public static void Load()
    {
        try
        {
            Knowledge = JsonConvert.DeserializeObject<Dictionary<string, Probil>>(File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "\\Knowledge.json"));
        }
        catch
        {
            Knowledge = new Dictionary<string, Probil>();
        }
    }

    private static string Command(string Input)
    {
        switch (Input)
        {
            case "help":
                return "!good - Reinforce last response\n!bad - Discourage last song\n!save - Save current knowledge databanks to .json\n!add - Add a new query/response set";
            case "good":
                Knowledge[LastInput].Reinforce();
                return "Reinforcement successful.";
            case "bad":
                Knowledge[LastInput].Discourage();
                return "Discouragement successful.";
            case "save":
                Save();
                Reactor.Save();
                return "Saved.";
            case "add":
                Console.WriteLine("What new phrase do you want to recognize?");
                string Phrase = Console.ReadLine();
                Console.WriteLine("In order from Happy, Sad, Afraid, to Angry, how should I emotionally respond to this? (Ideally -3 to +3)");
                int[] Reactions = new int[4];
                for (int i = 0; i < 4; i++)
                    Reactions[i] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("In order from Happy, Sad, Afraid, to Angry, please tell me some appropriate responses.");
                string[] Knowledges = new string[4];
                for (int i = 0; i < 4; i++)
                    Knowledges[i] = Console.ReadLine();
                Knowledge.Add(Phrase, new Probil(Knowledges[0], Knowledges[1], Knowledges[2], Knowledges[3]));
                return "Addition successful.";
            default:
                return "Unknown command '" + Input + "'";
        }
    }

    public static string GetResponse(string Input)
    {
        if (Input[0] == '!')
            return Command(Input.Substring(1));
        Tuple<int, string> Shortest = new Tuple<int, string>(int.MaxValue, "");
        foreach (string s in Knowledge.Keys.ToArray())
        {
            int Distance = DLDistance(s, Input);
            if (Distance < Shortest.Item1)
                Shortest = new Tuple<int, string>(Distance, s);
        }
        Console.WriteLine("DEBUG: Assuming input '" + Shortest.Item2 + "' with a distance of " + Shortest.Item1);
        Input = Shortest.Item2;
        LastInput = Input;
        Reactor.React(Input);
        return Knowledge[Input].Get();
    }

    private static int DLDistance(string Original, string Modified)
    {
        //Not my algorithm, I used someone else's under the terms of their license.
        //Original: https://gist.github.com/wickedshimmy/449595/cb33c2d0369551d1aa5b6ff5e6a802e21ba4ad5c

        int len_orig = Original.Length;
        int len_diff = Modified.Length;

        var matrix = new int[len_orig + 1, len_diff + 1];
        for (int i = 0; i <= len_orig; i++)
            matrix[i, 0] = i;
        for (int j = 0; j <= len_diff; j++)
            matrix[0, j] = j;

        for (int i = 1; i <= len_orig; i++)
        {
            for (int j = 1; j <= len_diff; j++)
            {
                int cost = Modified[j - 1] == Original[i - 1] ? 0 : 1;
                var vals = new int[] {
                matrix[i - 1, j] + 1,
                matrix[i, j - 1] + 1,
                matrix[i - 1, j - 1] + cost
            };
                matrix[i, j] = vals.Min();
                if (i > 1 && j > 1 && Original[i - 1] == Modified[j - 2] && Original[i - 2] == Modified[j - 1])
                    matrix[i, j] = Math.Min(matrix[i, j], matrix[i - 2, j - 2] + cost);
            }
        }
        return matrix[len_orig, len_diff];
    }
}